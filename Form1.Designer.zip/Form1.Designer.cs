﻿
namespace projectTwo
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.nameTextBox = new System.Windows.Forms.TextBox();
            this.crustTextBox = new System.Windows.Forms.TextBox();
            this.sizeTextBox = new System.Windows.Forms.TextBox();
            this.nameLabel = new System.Windows.Forms.Label();
            this.pizzaLabel = new System.Windows.Forms.Label();
            this.crustLabel = new System.Windows.Forms.Label();
            this.typeOfCrustLabel = new System.Windows.Forms.Label();
            this.sizeLabel = new System.Windows.Forms.Label();
            this.addtlToppingLabel = new System.Windows.Forms.Label();
            this.toppingsLabel = new System.Windows.Forms.Label();
            this.instructionCrustLabel = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.chickenPictureBox = new System.Windows.Forms.PictureBox();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.orderButton = new System.Windows.Forms.Button();
            this.clearButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.extraCheeseCheckBox = new System.Windows.Forms.CheckBox();
            this.chicikenCheckBox = new System.Windows.Forms.CheckBox();
            this.mushroomsCheckBox = new System.Windows.Forms.CheckBox();
            this.blackOlivesCheckBox = new System.Windows.Forms.CheckBox();
            this.orderConfirmationLabel = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.orderLabel = new System.Windows.Forms.Label();
            this.fourInchLabel = new System.Windows.Forms.Label();
            this.sevenInchLabel = new System.Windows.Forms.Label();
            this.tenInchLabel = new System.Windows.Forms.Label();
            this.fourteenInchLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.chickenPictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.SuspendLayout();
            // 
            // nameTextBox
            // 
            this.nameTextBox.Location = new System.Drawing.Point(438, 277);
            this.nameTextBox.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.nameTextBox.Name = "nameTextBox";
            this.nameTextBox.Size = new System.Drawing.Size(148, 26);
            this.nameTextBox.TabIndex = 0;
            // 
            // crustTextBox
            // 
            this.crustTextBox.Location = new System.Drawing.Point(438, 463);
            this.crustTextBox.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.crustTextBox.Name = "crustTextBox";
            this.crustTextBox.Size = new System.Drawing.Size(148, 26);
            this.crustTextBox.TabIndex = 1;
            // 
            // sizeTextBox
            // 
            this.sizeTextBox.Location = new System.Drawing.Point(438, 369);
            this.sizeTextBox.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.sizeTextBox.Name = "sizeTextBox";
            this.sizeTextBox.Size = new System.Drawing.Size(148, 26);
            this.sizeTextBox.TabIndex = 2;
            // 
            // nameLabel
            // 
            this.nameLabel.Cursor = System.Windows.Forms.Cursors.Default;
            this.nameLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nameLabel.ForeColor = System.Drawing.Color.Red;
            this.nameLabel.Location = new System.Drawing.Point(96, 267);
            this.nameLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.nameLabel.Name = "nameLabel";
            this.nameLabel.Size = new System.Drawing.Size(315, 41);
            this.nameLabel.TabIndex = 7;
            this.nameLabel.Text = "Enter your first name for the order";
            // 
            // pizzaLabel
            // 
            this.pizzaLabel.AutoSize = true;
            this.pizzaLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pizzaLabel.ForeColor = System.Drawing.Color.Red;
            this.pizzaLabel.Location = new System.Drawing.Point(100, 349);
            this.pizzaLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.pizzaLabel.Name = "pizzaLabel";
            this.pizzaLabel.Size = new System.Drawing.Size(278, 20);
            this.pizzaLabel.TabIndex = 8;
            this.pizzaLabel.Text = "What size pizza would you like?";
            // 
            // crustLabel
            // 
            this.crustLabel.AutoSize = true;
            this.crustLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.crustLabel.ForeColor = System.Drawing.Color.Red;
            this.crustLabel.Location = new System.Drawing.Point(106, 437);
            this.crustLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.crustLabel.Name = "crustLabel";
            this.crustLabel.Size = new System.Drawing.Size(291, 20);
            this.crustLabel.TabIndex = 9;
            this.crustLabel.Text = "What type of crust do you prefer?";
            // 
            // typeOfCrustLabel
            // 
            this.typeOfCrustLabel.AutoSize = true;
            this.typeOfCrustLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.typeOfCrustLabel.Location = new System.Drawing.Point(92, 463);
            this.typeOfCrustLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.typeOfCrustLabel.Name = "typeOfCrustLabel";
            this.typeOfCrustLabel.Size = new System.Drawing.Size(335, 20);
            this.typeOfCrustLabel.TabIndex = 10;
            this.typeOfCrustLabel.Text = "(T) Thin, (R) Regular, (G)  Gluten Free";
            // 
            // sizeLabel
            // 
            this.sizeLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sizeLabel.Location = new System.Drawing.Point(100, 374);
            this.sizeLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.sizeLabel.Name = "sizeLabel";
            this.sizeLabel.Size = new System.Drawing.Size(328, 46);
            this.sizeLabel.TabIndex = 11;
            this.sizeLabel.Text = "4, 7, 10, 14 (Enter the number only)";
            // 
            // addtlToppingLabel
            // 
            this.addtlToppingLabel.AutoSize = true;
            this.addtlToppingLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.addtlToppingLabel.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.addtlToppingLabel.Location = new System.Drawing.Point(676, 463);
            this.addtlToppingLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.addtlToppingLabel.Name = "addtlToppingLabel";
            this.addtlToppingLabel.Size = new System.Drawing.Size(682, 20);
            this.addtlToppingLabel.TabIndex = 13;
            this.addtlToppingLabel.Text = "Additional toppings/modifiers incur a $1.25 fee each, Choose from the following:";
            // 
            // toppingsLabel
            // 
            this.toppingsLabel.AutoSize = true;
            this.toppingsLabel.Location = new System.Drawing.Point(686, 505);
            this.toppingsLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.toppingsLabel.Name = "toppingsLabel";
            this.toppingsLabel.Size = new System.Drawing.Size(395, 20);
            this.toppingsLabel.TabIndex = 14;
            this.toppingsLabel.Text = "Extra Cheese, Extra Chicken, Mushrooms, Black Olives";
            // 
            // instructionCrustLabel
            // 
            this.instructionCrustLabel.AutoSize = true;
            this.instructionCrustLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.instructionCrustLabel.Location = new System.Drawing.Point(434, 498);
            this.instructionCrustLabel.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.instructionCrustLabel.Name = "instructionCrustLabel";
            this.instructionCrustLabel.Size = new System.Drawing.Size(131, 20);
            this.instructionCrustLabel.TabIndex = 15;
            this.instructionCrustLabel.Text = "Enter T, R, or G.";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Perpetua Titling MT", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(64, 58);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(658, 64);
            this.label1.TabIndex = 16;
            this.label1.Text = "Al Amir Flatbreads";
            // 
            // chickenPictureBox
            // 
            this.chickenPictureBox.Image = ((System.Drawing.Image)(resources.GetObject("chickenPictureBox.Image")));
            this.chickenPictureBox.Location = new System.Drawing.Point(642, 216);
            this.chickenPictureBox.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.chickenPictureBox.Name = "chickenPictureBox";
            this.chickenPictureBox.Size = new System.Drawing.Size(96, 92);
            this.chickenPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.chickenPictureBox.TabIndex = 19;
            this.chickenPictureBox.TabStop = false;
            // 
            // listBox1
            // 
            this.listBox1.BackColor = System.Drawing.Color.YellowGreen;
            this.listBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.listBox1.FormattingEnabled = true;
            this.listBox1.ItemHeight = 20;
            this.listBox1.Items.AddRange(new object[] {
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "",
            "The cost of your order is:",
            "",
            "The tax is:",
            "",
            "The total due is:",
            "",
            "",
            "\t\tYour order will be ready in about 30 minutes."});
            this.listBox1.Location = new System.Drawing.Point(1397, 203);
            this.listBox1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(590, 422);
            this.listBox1.TabIndex = 21;
            // 
            // orderButton
            // 
            this.orderButton.BackColor = System.Drawing.Color.Green;
            this.orderButton.Location = new System.Drawing.Point(1522, 676);
            this.orderButton.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.orderButton.Name = "orderButton";
            this.orderButton.Size = new System.Drawing.Size(116, 60);
            this.orderButton.TabIndex = 22;
            this.orderButton.Text = "Order";
            this.orderButton.UseVisualStyleBackColor = false;
            this.orderButton.Click += new System.EventHandler(this.orderButton_Click);
            // 
            // clearButton
            // 
            this.clearButton.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.clearButton.Location = new System.Drawing.Point(1646, 676);
            this.clearButton.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.clearButton.Name = "clearButton";
            this.clearButton.Size = new System.Drawing.Size(126, 60);
            this.clearButton.TabIndex = 23;
            this.clearButton.Text = "Clear";
            this.clearButton.UseVisualStyleBackColor = false;
            // 
            // exitButton
            // 
            this.exitButton.BackColor = System.Drawing.Color.Red;
            this.exitButton.Location = new System.Drawing.Point(1781, 676);
            this.exitButton.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(124, 60);
            this.exitButton.TabIndex = 24;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = false;
            // 
            // extraCheeseCheckBox
            // 
            this.extraCheeseCheckBox.AutoSize = true;
            this.extraCheeseCheckBox.Location = new System.Drawing.Point(843, 568);
            this.extraCheeseCheckBox.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.extraCheeseCheckBox.Name = "extraCheeseCheckBox";
            this.extraCheeseCheckBox.Size = new System.Drawing.Size(90, 24);
            this.extraCheeseCheckBox.TabIndex = 25;
            this.extraCheeseCheckBox.Text = "Cheese";
            this.extraCheeseCheckBox.UseVisualStyleBackColor = true;
            // 
            // chicikenCheckBox
            // 
            this.chicikenCheckBox.AutoSize = true;
            this.chicikenCheckBox.Location = new System.Drawing.Point(1074, 568);
            this.chicikenCheckBox.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.chicikenCheckBox.Name = "chicikenCheckBox";
            this.chicikenCheckBox.Size = new System.Drawing.Size(92, 24);
            this.chicikenCheckBox.TabIndex = 26;
            this.chicikenCheckBox.Text = "Chicken";
            this.chicikenCheckBox.UseVisualStyleBackColor = true;
            // 
            // mushroomsCheckBox
            // 
            this.mushroomsCheckBox.AutoSize = true;
            this.mushroomsCheckBox.Location = new System.Drawing.Point(841, 646);
            this.mushroomsCheckBox.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.mushroomsCheckBox.Name = "mushroomsCheckBox";
            this.mushroomsCheckBox.Size = new System.Drawing.Size(118, 24);
            this.mushroomsCheckBox.TabIndex = 27;
            this.mushroomsCheckBox.Text = "Mushrooms";
            this.mushroomsCheckBox.UseVisualStyleBackColor = true;
            // 
            // blackOlivesCheckBox
            // 
            this.blackOlivesCheckBox.AutoSize = true;
            this.blackOlivesCheckBox.Location = new System.Drawing.Point(1074, 650);
            this.blackOlivesCheckBox.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.blackOlivesCheckBox.Name = "blackOlivesCheckBox";
            this.blackOlivesCheckBox.Size = new System.Drawing.Size(120, 24);
            this.blackOlivesCheckBox.TabIndex = 28;
            this.blackOlivesCheckBox.Text = "Black Olives";
            this.blackOlivesCheckBox.UseVisualStyleBackColor = true;
            // 
            // orderConfirmationLabel
            // 
            this.orderConfirmationLabel.AutoSize = true;
            this.orderConfirmationLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.orderConfirmationLabel.Location = new System.Drawing.Point(1397, 143);
            this.orderConfirmationLabel.Name = "orderConfirmationLabel";
            this.orderConfirmationLabel.Size = new System.Drawing.Size(243, 25);
            this.orderConfirmationLabel.TabIndex = 30;
            this.orderConfirmationLabel.Text = "Your order is as follows:";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(1124, 83);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(234, 227);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 31;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(918, 134);
            this.pictureBox2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(185, 174);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 32;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(761, 177);
            this.pictureBox3.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(137, 131);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 33;
            this.pictureBox3.TabStop = false;
            // 
            // orderLabel
            // 
            this.orderLabel.BackColor = System.Drawing.Color.White;
            this.orderLabel.Location = new System.Drawing.Point(1428, 216);
            this.orderLabel.Name = "orderLabel";
            this.orderLabel.Size = new System.Drawing.Size(540, 179);
            this.orderLabel.TabIndex = 34;
            // 
            // fourInchLabel
            // 
            this.fourInchLabel.AutoSize = true;
            this.fourInchLabel.Location = new System.Drawing.Point(653, 313);
            this.fourInchLabel.Name = "fourInchLabel";
            this.fourInchLabel.Size = new System.Drawing.Size(69, 20);
            this.fourInchLabel.TabIndex = 35;
            this.fourInchLabel.Text = "4-inches";
            // 
            // sevenInchLabel
            // 
            this.sevenInchLabel.AutoSize = true;
            this.sevenInchLabel.Location = new System.Drawing.Point(797, 313);
            this.sevenInchLabel.Name = "sevenInchLabel";
            this.sevenInchLabel.Size = new System.Drawing.Size(69, 20);
            this.sevenInchLabel.TabIndex = 36;
            this.sevenInchLabel.Text = "7-inches";
            // 
            // tenInchLabel
            // 
            this.tenInchLabel.AutoSize = true;
            this.tenInchLabel.Location = new System.Drawing.Point(975, 313);
            this.tenInchLabel.Name = "tenInchLabel";
            this.tenInchLabel.Size = new System.Drawing.Size(78, 20);
            this.tenInchLabel.TabIndex = 37;
            this.tenInchLabel.Text = "10-inches";
            // 
            // fourteenInchLabel
            // 
            this.fourteenInchLabel.AutoSize = true;
            this.fourteenInchLabel.Location = new System.Drawing.Point(1208, 313);
            this.fourteenInchLabel.Name = "fourteenInchLabel";
            this.fourteenInchLabel.Size = new System.Drawing.Size(78, 20);
            this.fourteenInchLabel.TabIndex = 38;
            this.fourteenInchLabel.Text = "14-inches";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.YellowGreen;
            this.ClientSize = new System.Drawing.Size(2002, 756);
            this.Controls.Add(this.fourteenInchLabel);
            this.Controls.Add(this.tenInchLabel);
            this.Controls.Add(this.sevenInchLabel);
            this.Controls.Add(this.fourInchLabel);
            this.Controls.Add(this.orderLabel);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.pictureBox2);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.orderConfirmationLabel);
            this.Controls.Add(this.listBox1);
            this.Controls.Add(this.blackOlivesCheckBox);
            this.Controls.Add(this.mushroomsCheckBox);
            this.Controls.Add(this.chicikenCheckBox);
            this.Controls.Add(this.extraCheeseCheckBox);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.clearButton);
            this.Controls.Add(this.orderButton);
            this.Controls.Add(this.chickenPictureBox);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.instructionCrustLabel);
            this.Controls.Add(this.toppingsLabel);
            this.Controls.Add(this.addtlToppingLabel);
            this.Controls.Add(this.sizeLabel);
            this.Controls.Add(this.typeOfCrustLabel);
            this.Controls.Add(this.crustLabel);
            this.Controls.Add(this.pizzaLabel);
            this.Controls.Add(this.nameLabel);
            this.Controls.Add(this.sizeTextBox);
            this.Controls.Add(this.crustTextBox);
            this.Controls.Add(this.nameTextBox);
            this.Name = "Form1";
            this.Text = "Al Amir Flatbreads Order Form";
            ((System.ComponentModel.ISupportInitialize)(this.chickenPictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox nameTextBox;
        private System.Windows.Forms.TextBox crustTextBox;
        private System.Windows.Forms.TextBox sizeTextBox;
        private System.Windows.Forms.Label nameLabel;
        private System.Windows.Forms.Label pizzaLabel;
        private System.Windows.Forms.Label crustLabel;
        private System.Windows.Forms.Label typeOfCrustLabel;
        private System.Windows.Forms.Label sizeLabel;
        private System.Windows.Forms.Label addtlToppingLabel;
        private System.Windows.Forms.Label toppingsLabel;
        private System.Windows.Forms.Label instructionCrustLabel;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox chickenPictureBox;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.Button orderButton;
        private System.Windows.Forms.Button clearButton;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.CheckBox extraCheeseCheckBox;
        private System.Windows.Forms.CheckBox chicikenCheckBox;
        private System.Windows.Forms.CheckBox mushroomsCheckBox;
        private System.Windows.Forms.CheckBox blackOlivesCheckBox;
        private System.Windows.Forms.Label orderConfirmationLabel;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Label orderLabel;
        private System.Windows.Forms.Label fourInchLabel;
        private System.Windows.Forms.Label sevenInchLabel;
        private System.Windows.Forms.Label tenInchLabel;
        private System.Windows.Forms.Label fourteenInchLabel;
    }
}

